<?php 
// Step 1: Database Connect karna zaroori hai
include('db.php'); 
include 'header.php'; 
?>

  <section class="hero">
    <div class="hero-content">
      <h1>Empowering Innovation at<br>FJWU STEM Society</h1>
      <p>
        Welcome to the official portal. Join a community of innovators, thinkers, and leaders. 
        Register now to get your STEM ID, join chapters, and participate in university-wide events.
      </p>
      <div class="hero-buttons">
        <a href="register.php" class="btn">Register Now</a>
        <a href="#features" class="btn btn-outline">Explore Features</a>
      </div>
    </div>
  </section>

  <section class="section" id="features">
    <h2>Why Join STEM?</h2>
    <div class="grid">
      <div class="card">
        <h3><i class="fas fa-id-card"></i> Get STEM ID</h3>
        <p>Register online and generate your unique STEM ID automatically. No more manual paperwork. Build your profile and track your activities.</p>
      </div>
      <div class="card">
        <h3><i class="fas fa-users"></i> Select Chapter</h3>
        <p>Choose your interest! Whether it's CS, Engineering, or Sciences, link your STEM ID to specific chapters like GGDGC or MLSA.</p>
      </div>
      <div class="card">
        <h3><i class="fas fa-calendar-alt"></i> Event Updates</h3>
        <p>Never miss an opportunity. Get notifications for seminars, workshops, and competitions happening at FJWU.</p>
      </div>
      <div class="card">
        <h3><i class="fas fa-images"></i> Digital Gallery</h3>
        <p>Relive the best moments. Access high-quality pictures and details from past events in our dedicated gallery section.</p>
      </div>
    </div>
  </section>

  <section class="section events" id="events" style="background: #fff;">
    <h2>Upcoming Events</h2>
    <div class="grid">
      
      <?php
        // Step 2: Database se Events mangwana
        // Hum keh rahay hain: "Events table se sab kuch lao, aur naye events pehle dikhao (DESC)"
        $query = "SELECT * FROM events ORDER BY event_date ASC";
        $query_run = mysqli_query($conn, $query);

        // Check karna ke koi event hai bhi ya nahi?
        if(mysqli_num_rows($query_run) > 0)
        {
            // Step 3: Loop chalana (Jitne events hon gay, utne cards banain gay)
            while($row = mysqli_fetch_assoc($query_run))
            {
                // Date ko khubsurat format main badalna (e.g., 2025-10-20 -> Oct 20, 2025)
                $formatted_date = date('M d, Y', strtotime($row['event_date']));
                ?>
                
                <div class="card">
                    <span style="display: inline-block; background: #e8f5e9; color: #168a53; padding: 5px 12px; border-radius: 15px; font-size: 0.9rem; font-weight: bold; margin-bottom: 10px;">
                        <?= $formatted_date; ?>
                    </span>
                    
                    <h3><?= $row['title']; ?></h3>
                    
                    <p><strong>Venue:</strong> <?= $row['venue']; ?></p>
                    
                    <p style="margin-top: 10px; font-size: 0.95rem; color: #555;">
                        <?= $row['description']; ?>
                    </p>
                    
                    <br>
                    <a href="event-details.php?id=<?= $row['id']; ?>" class="btn" style="padding: 8px 20px; font-size: 0.9rem; text-decoration: none; display:inline-block;">View Details</a>
                </div>

                <?php
            }
        }
        else
        {
            // Agar koi event na ho tou ye message show hoga
            echo '<p style="width:100%; text-align:center; color:#777;">No Upcoming Events Found</p>';
        }
      ?>

    </div>
  </section>

  <section class="section" id="gallery">
    <h2>Event Highlights</h2>
    <div class="gallery-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
      
      <?php
        $gallery_query = "SELECT * FROM gallery_images ORDER BY id DESC LIMIT 8"; // Show last 8 images
        $gallery_run = mysqli_query($conn, $gallery_query);

        if(mysqli_num_rows($gallery_run) > 0)
        {
            while($img = mysqli_fetch_assoc($gallery_run))
            {
                ?>
                <div style="position: relative; overflow: hidden; border-radius: 15px;">
                    <img src="uploads/<?= $img['image_path']; ?>" 
                         alt="<?= $img['caption']; ?>" 
                         style="width: 100%; height: 250px; object-fit: cover; transition: transform 0.3s;">
                    <?php if($img['caption']): ?>
                        <div style="position: absolute; bottom: 0; background: rgba(0,0,0,0.6); color: white; width: 100%; padding: 8px; text-align: center; font-size: 0.9rem;">
                            <?= $img['caption']; ?>
                        </div>
                    <?php endif; ?>
                </div>
                <?php
            }
        }
        else
        {
            echo '<p style="width:100%; text-align:center; color:#777;">No Images Uploaded Yet.</p>';
        }
      ?>

    </div>
  </section>

<?php include 'footer.php'; ?>