<?php
session_start();
include('db.php');

if(isset($_POST['approve_btn']))
{
    $nomination_id = $_POST['nomination_id'];
    
    $query = "UPDATE nominations SET status='approved' WHERE id='$nomination_id'";
    $query_run = mysqli_query($conn, $query);

    if($query_run) {
        $_SESSION['message'] = "Nomination Approved Successfully!";
    } else {
        $_SESSION['message'] = "Something went wrong!";
    }
    header("Location: admin-nominations.php");
    exit(0);
}

if(isset($_POST['reject_btn']))
{
    $nomination_id = $_POST['nomination_id'];
    
    $query = "UPDATE nominations SET status='rejected' WHERE id='$nomination_id'";
    $query_run = mysqli_query($conn, $query);

    if($query_run) {
        $_SESSION['message'] = "Nomination Rejected!";
    } else {
        $_SESSION['message'] = "Something went wrong!";
    }
    header("Location: admin-nominations.php");
    exit(0);
}
?>