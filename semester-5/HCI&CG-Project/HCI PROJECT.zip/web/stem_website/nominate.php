<?php
session_start();
include('db.php'); // Database connection file

// 1. Authentication Check
if(!isset($_SESSION['auth']) || $_SESSION['auth_user']['role'] !== 'student')
{
    $_SESSION['message'] = "Please Login as a Student to access the nomination form.";
    header("Location: login.php");
    exit(0);
}

$user_id = $_SESSION['auth_user']['user_id'];
$semester = $_SESSION['auth_user']['semester'];

// 2. Fetch Role ID from URL
if(!isset($_GET['role_id']) || empty($_GET['role_id']))
{
    $_SESSION['message'] = "Invalid role selected.";
    header("Location: student-dashboard.php");
    exit(0);
}

$role_id = mysqli_real_escape_string($conn, $_GET['role_id']);

// --- FIX: Simple query without 'status' check for cabinet_roles ---
$role_query = "SELECT * FROM cabinet_roles WHERE id='$role_id' LIMIT 1";
$role_run = mysqli_query($conn, $role_query);

if(mysqli_num_rows($role_run) == 0)
{
    $_SESSION['message'] = "Selected role not found.";
    header("Location: student-dashboard.php");
    exit(0);
}

$role = mysqli_fetch_assoc($role_run);

// 3. Eligibility Check
if ($semester < $role['min_semester'] || $semester > $role['max_semester'])
{
    $_SESSION['message'] = "You are not eligible for " . htmlspecialchars($role['role_name']) . " (Requires Semester " . $role['min_semester'] . "-" . $role['max_semester'] . ").";
    header("Location: student-dashboard.php");
    exit(0);
}

// 4. Check if already nominated (Checking 'nominations' table which HAS status)
$check_nomination_query = "SELECT * FROM nominations WHERE user_id='$user_id' AND role_id='$role_id' AND status!='rejected' LIMIT 1";
$check_nomination_run = mysqli_query($conn, $check_nomination_query);

if(mysqli_num_rows($check_nomination_run) > 0)
{
    $_SESSION['message'] = "You have already nominated yourself for " . htmlspecialchars($role['role_name']) . ".";
    header("Location: student-dashboard.php");
    exit(0);
}

// 5. Handle Form Submission
if(isset($_POST['nominate_btn']))
{
    $manifesto = mysqli_real_escape_string($conn, $_POST['manifesto']);
    $role_name = mysqli_real_escape_string($conn, $role['role_name']); // Role name safe fetch

    if(strlen(trim($manifesto)) < 50) // Validation relax kar di thodi testing ke liye
    {
        $_SESSION['message'] = "Manifesto is too short. Please write at least 50 characters.";
        header("Location: nominate.php?role_id=$role_id");
        exit(0);
    }
    
    // Insert into nominations
    $insert_query = "INSERT INTO nominations (user_id, role_id, role_name, manifesto, status) 
                     VALUES ('$user_id', '$role_id', '$role_name', '$manifesto', 'pending')";
    
    if(mysqli_query($conn, $insert_query))
    {
        $_SESSION['message'] = "Nomination Submitted Successfully! Awaiting Approval.";
        header("Location: student-dashboard.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Database Error: " . mysqli_error($conn);
        header("Location: nominate.php?role_id=$role_id");
        exit(0);
    }
}

include 'header.php'; 
?>

<div class="section" style="padding-top: 100px; min-height: 100vh;">
    <div class="container" style="max-width: 800px; margin: 0 auto; padding: 20px;">
        <h2 style="text-align: center; margin-bottom: 30px;">
            <i class="fa-solid fa-file-signature" style="margin-right: 10px;"></i> Nominate for <?= htmlspecialchars($role['role_name']); ?>
        </h2>

        <!-- Message Alert -->
        <?php if(isset($_SESSION['message'])): ?>
            <div style="padding: 15px; margin-bottom: 25px; border-radius: 10px; font-weight: bold; background: #f0ad4e; color: #8a6d3b; border: 1px solid #ebccd1;">
                <?= $_SESSION['message']; ?>
            </div>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>

        <!-- Role Details Card -->
        <div class="glass" style="max-width: none; margin-top: 0; margin-bottom: 30px; text-align: left;">
            <h3 style="margin-bottom: 15px; color: var(--green-dark);"><?= htmlspecialchars($role['role_name']); ?> Details</h3>
            <p style="color: #555; margin-bottom: 10px;">
                <strong>Description:</strong> <?= htmlspecialchars($role['description']); ?>
            </p>
            <p style="font-weight: bold; color: #5bc0de;">
                Eligibility: Semester <?= htmlspecialchars($role['min_semester']); ?> - <?= htmlspecialchars($role['max_semester']); ?>
            </p>
        </div>

        <!-- Nomination Form -->
        <div class="glass" style="max-width: none;">
            <form action="nominate.php?role_id=<?= $role_id; ?>" method="POST">
                <div style="margin-bottom: 20px;">
                    <label for="manifesto" style="display: block; margin-bottom: 8px; font-weight: 600; color: #333;">
                        Your Election Manifesto
                    </label>
                    <textarea 
                        name="manifesto" 
                        id="manifesto" 
                        rows="10" 
                        required 
                        style="width: 100%; padding: 15px; border: 1px solid #ccc; border-radius: 8px; resize: vertical; font-size: 1rem;" 
                        placeholder="Detail your vision, goals, and plan of action if elected."></textarea>
                    <small style="color: #666;">Please write at least 50 characters.</small>
                </div>

                <div style="display: flex; justify-content: space-between; gap: 10px;">
                    <a href="student-dashboard.php" class="btn btn-outline" style="flex-grow: 1; text-align: center; background-color: #6c757d; color: white; border: none; padding: 12px 20px; border-radius: 8px; text-decoration: none; font-weight: bold;">
                        Cancel
                    </a>
                    <button type="submit" name="nominate_btn" class="btn" style="flex-grow: 3; background-color: var(--green-dark); color: white; border: none; padding: 12px 20px; border-radius: 8px; font-weight: bold; cursor: pointer; transition: background-color 0.3s;">
                        Submit Nomination
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>