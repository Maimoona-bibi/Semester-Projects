<?php
session_start();
include('db.php');

// REGISTER USER
if(isset($_POST['register_btn']))
{
    // PHP Code Fix: Variable ka naam database se match karne ke liye $fullname se $full_name kiya gaya.
    $full_name = mysqli_real_escape_string($conn, $_POST['fullname']); // Form se 'fullname' aa raha hai
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $cpassword = mysqli_real_escape_string($conn, $_POST['cpassword']);
    
    // NEW: Semester aur Chapter ID fetch karna
    $semester = mysqli_real_escape_string($conn, $_POST['semester']);
    $chapter_id = mysqli_real_escape_string($conn, $_POST['chapter_id']);
    
    // Check if email already exists
    $check_email_query = "SELECT email FROM users WHERE email='$email' LIMIT 1";
    $check_email_run = mysqli_query($conn, $check_email_query);

    if(mysqli_num_rows($check_email_run) > 0)
    {
        $_SESSION['message'] = "Email already registered!";
        header("Location: register.php");
        exit(0);
    }
    else
    {
        // Check if passwords match
        if($password == $cpassword)
        {
            // Hash password and insert user data
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $role = 'student'; // Default role is student

            // Database main column ka naam 'full_name' use kiya gaya.
            // NEW: 'semester' column ko query mein shamil kiya gaya
            $query = "INSERT INTO users (full_name, email, password, role, chapter_id, semester) 
                      VALUES ('$full_name', '$email', '$hashed_password', '$role', '$chapter_id', '$semester')";
            
            $query_run = mysqli_query($conn, $query);

            if($query_run)
            {
                $_SESSION['message'] = "Registration Successful! You can now Login.";
                header("Location: login.php");
                exit(0);
            }
            else
            {
                // Agar query fail ho, toh error message main reason bhi print karwao
                $_SESSION['message'] = "Registration Failed! Error: " . mysqli_error($conn);
                header("Location: register.php");
                exit(0);
            }
        }
        else
        {
            $_SESSION['message'] = "Passwords do not match!";
            header("Location: register.php");
            exit(0);
        }
    }
}


// LOGIN USER
if(isset($_POST['login_btn']))
{
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    
    $login_query = "SELECT * FROM users WHERE email='$email' LIMIT 1";
    $login_query_run = mysqli_query($conn, $login_query);

    if(mysqli_num_rows($login_query_run) > 0)
    {
        $user_data = mysqli_fetch_assoc($login_query_run);
        $hashed_password = $user_data['password'];

        if(password_verify($password, $hashed_password))
        {
            $_SESSION['auth'] = true;
            
            // Database se 'full_name', 'chapter_id', aur 'semester' column fetch kiya aur session mein store kiya
            $_SESSION['auth_user'] = [
                'user_id' => $user_data['id'],
                'full_name' => $user_data['full_name'], 
                'email' => $user_data['email'],
                'role' => $user_data['role'],
                'chapter_id' => $user_data['chapter_id'] ?? null, 
                'semester' => $user_data['semester'] ?? 1, // NEW: Semester store kiya
            ];

            if($user_data['role'] == 'admin')
            {
                $_SESSION['message'] = "Welcome to Admin Dashboard!";
                header("Location: admin-dashboard.php");
                exit(0);
            }
            else
            {
                $_SESSION['message'] = "Welcome Back, " . $user_data['full_name'] . "!";
                header("Location: student-dashboard.php");
                exit(0);
            }
        }
        else
        {
            $_SESSION['message'] = "Invalid Email or Password!";
            header("Location: login.php");
            exit(0);
        }
    }
    else
    {
        $_SESSION['message'] = "Invalid Email or Password!";
        header("Location: login.php");
        exit(0);
    }
}
?>