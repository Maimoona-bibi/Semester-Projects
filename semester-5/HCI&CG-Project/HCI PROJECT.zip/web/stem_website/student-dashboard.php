<?php
session_start();
include('db.php'); // Database connection file

// --- 1. Authentication Check ---
if(!isset($_SESSION['auth']) || !isset($_SESSION['auth_user']))
{
    $_SESSION['message'] = "Please Login to access the Student Dashboard.";
    header("Location: login.php");
    exit(0);
}

$auth_user = $_SESSION['auth_user'];
$role = $auth_user['role'] ?? 'guest';

// Security: Ensure only students can see this page
if($role !== 'student')
{
    $_SESSION['message'] = "Access Denied: Not a Student. You are logged in as " . strtoupper($role);
    header("Location: index.php"); 
    exit(0);
}

// --- 2. Safely Retrieving Profile Data from Session ---
$name = $auth_user['name'] ?? 'N/A';
$reg_no = $auth_user['reg_no'] ?? 'N/A';
$semester = $auth_user['semester'] ?? 'N/A';
$chapter_id = $auth_user['chapter_id'] ?? null;
$user_id = $auth_user['user_id'] ?? 0;

$chapter_name = 'N/A'; 

// --- 3. Fetch Chapter Name ---
if ($chapter_id && $chapter_id !== 'N/A') {
    $safe_chapter_id = mysqli_real_escape_string($conn, $chapter_id);
    $chapter_query = "SELECT chapter_name FROM chapters WHERE id='$safe_chapter_id' LIMIT 1";
    $chapter_run = mysqli_query($conn, $chapter_query);
    if ($chapter_run && mysqli_num_rows($chapter_run) > 0) {
        $chapter_data = mysqli_fetch_assoc($chapter_run);
        $chapter_name = htmlspecialchars($chapter_data['chapter_name']);
    } else {
        $chapter_name = '<span style="color: red; font-weight: bold;">Chapter Not Found</span>';
    }
} else {
    $chapter_name = '<span style="color: red; font-weight: bold;">Not Selected / Missing Data</span>';
}

// --- 4. Fetch Cabinet Roles and User's Nominations ---
$roles_query = "SELECT * FROM cabinet_roles ORDER BY min_semester DESC"; 
$roles_run = mysqli_query($conn, $roles_query);

if ($roles_run === false) {
    error_log("SQL Error in roles query: " . mysqli_error($conn));
    $roles_run = [];
}

$nominations = [];
if ($user_id != 0) {
    $nomination_query = "SELECT role_id, status FROM nominations WHERE user_id='$user_id'";
    $nomination_run = mysqli_query($conn, $nomination_query);
    while ($nomination = mysqli_fetch_assoc($nomination_run)) {
        // --- FIXED LINE 63 IS HERE ---
        // Pehle yahan $role['id'] tha jo ghalat tha. Sahi $nomination['role_id'] hai.
        $nominations[$nomination['role_id']] = $nomination['status'];
    }
}

// --- 5. HTML Output ---
include 'header.php';
?>

<div class="section" style="padding-top: 120px; min-height: 100vh;">
    <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 20px;">
        <h2 style="text-align: center; margin-bottom: 30px;">
            <i class="fa-solid fa-graduation-cap" style="margin-right: 10px;"></i> Student Dashboard
        </h2>

        <!-- Message Alert -->
        <?php if(isset($_SESSION['message'])): ?>
            <div style="padding: 15px; margin-bottom: 25px; border-radius: 10px; font-weight: bold; background: #dff0d8; color: #3c763d; border: 1px solid #d6e9c6; text-align: center;">
                <?= $_SESSION['message']; ?>
            </div>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>

        <!-- User Profile Summary -->
        <div class="glass" style="max-width: 900px; margin: 30px auto; padding: 25px;">
            <h3 style="margin-bottom: 10px; color: var(--green-dark); text-align: center;">Your Profile Summary</h3>
            
            <div style="text-align: center; margin-bottom: 25px;">
                <a href="student-profile-edit.php" style="text-decoration: none; font-size: 0.9rem; color: #555; background: #f0f0f0; padding: 5px 15px; border-radius: 20px; border: 1px solid #ccc;">
                    <i class="fa-solid fa-pen-to-square"></i> Edit Profile / Change Password
                </a>
            </div>

            <div style="display: flex; justify-content: space-around; flex-wrap: wrap; text-align: center; gap: 20px;">
                <div style="flex-basis: 22%;">
                    <p style="font-weight: bold;">Name:</p>
                    <p><?= htmlspecialchars($name); ?></p>
                </div>
                <div style="flex-basis: 22%;">
                    <p style="font-weight: bold;">Reg No (STEM ID):</p>
                    <p><?= htmlspecialchars($reg_no); ?></p>
                </div>
                <div style="flex-basis: 22%;">
                    <p style="font-weight: bold;">Chapter:</p>
                    <p><?= $chapter_name; ?></p>
                </div>
                <div style="flex-basis: 22%;">
                    <p style="font-weight: bold;">Semester:</p>
                    <p><?= htmlspecialchars($semester); ?></p> 
                </div>
            </div>
            <p style="text-align: center; font-size: 0.9em; color: #777; margin-top: 20px;">
                <i class="fa-solid fa-circle-info"></i> Your eligibility for cabinet roles is checked based on your registered semester.
            </p>
        </div>

        <!-- Cabinet Elections Section -->
        <h3 style="text-align: center; margin-top: 50px; margin-bottom: 30px; color: var(--green-dark);">
            <i class="fa-solid fa-person-military-pointing" style="margin-right: 10px;"></i> Cabinet Elections: Nominate Yourself
        </h3>
        
        <div class="grid" style="grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));">
            <?php if(is_object($roles_run) && mysqli_num_rows($roles_run) > 0): ?>
                <?php foreach($roles_run as $role): 
                    $is_eligible = (is_numeric($semester) && $semester >= $role['min_semester'] && $semester <= $role['max_semester']); 
                    $current_status = $nominations[$role['id']] ?? 'none';
                ?>
                    <div class="card glass" style="text-align: left; padding: 25px;">
                        <h4 style="font-size: 1.5rem; color: var(--green-dark); margin-bottom: 10px; font-weight: bold;"><?= htmlspecialchars($role['role_name']); ?></h4>
                        <p style="font-size: 0.9em; color: #555; height: 70px; overflow: hidden;"><?= htmlspecialchars($role['description']); ?></p>
                        
                        <p style="margin-top: 15px; font-weight: 500; font-size: 0.9em;">
                            Eligibility: Semester <?= htmlspecialchars($role['min_semester']); ?> - <?= htmlspecialchars($role['max_semester']); ?>
                        </p>

                        <div style="margin-top: 20px;">
                            <?php if ($current_status == 'pending'): ?>
                                <button class="btn" disabled style="background-color: #f0ad4e; color: white; width: 100%; cursor: not-allowed;">
                                    Nomination Pending <i class="fa-solid fa-hourglass-half"></i>
                                </button>
                            <?php elseif ($current_status == 'approved'): ?>
                                <button class="btn" disabled style="background-color: var(--green-dark); color: white; width: 100%; cursor: not-allowed;">
                                    Nominated (Approved) <i class="fa-solid fa-check-circle"></i>
                                </button>
                            <?php elseif ($current_status == 'rejected'): ?>
                                <button class="btn" disabled style="background-color: #d9534f; color: white; width: 100%; cursor: not-allowed;">
                                    Nomination Rejected <i class="fa-solid fa-times-circle"></i>
                                </button>
                            <?php elseif ($is_eligible): ?>
                                <a href="nominate.php?role_id=<?= $role['id']; ?>" class="btn" style="background-color: var(--green1); color: var(--green-dark); width: 100%; text-align: center; text-decoration: none;">
                                    Nominate Yourself <i class="fa-solid fa-chevron-right"></i>
                                </a>
                            <?php else: ?>
                                <button class="btn" disabled style="background-color: #f7f7f7; color: #d9534f; width: 100%; border: 1px solid #d9534f; cursor: not-allowed;">
                                    Not Eligible (Requires Sem: <?= htmlspecialchars($role['min_semester']); ?>)
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p style="grid-column: 1 / -1; text-align: center; color: #888;">No active cabinet roles available for nomination right now.</p>
            <?php endif; ?>
        </div>

        <div style="text-align: center; margin-top: 50px;">
            <a href="logout.php" class="btn" style="background-color: #d9534f; color: white; padding: 10px 25px; text-decoration: none;">
                <i class="fa-solid fa-right-from-bracket" style="margin-right: 8px;"></i> Logout
            </a>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>