<!-- Footer -->
  <footer class="footer" id="contact">
    <h3>STEM Society FJWU</h3>
    <p>Empowering Women in Science & Technology</p>
    <br>
    <p>&copy; 2025 STEM Portal Team. All Rights Reserved.</p>
  </footer>

</body>
</html>