<?php
session_start();
include('db.php');

// Check validity: User login hai? Aur kya wo Admin hai?
if(!isset($_SESSION['auth']) || $_SESSION['auth_user']['role'] != 'admin'){
    $_SESSION['message'] = "You are not authorized to access Admin Panel";
    header("Location: login.php");
    exit(0);
}

include 'header.php';
?>

<div class="section" style="background: #f4f4f4; padding-top: 120px; min-height: 100vh;">
    <div class="container" style="max-width: 1100px; margin: 0 auto; text-align: left;">
        
        <!-- Header with Logout -->
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
            <h2 style="margin: 0; color: var(--green-dark);">Admin Dashboard</h2>
            <a href="logout.php" class="btn" style="background: #dc3545; padding: 10px 20px; font-size: 0.9rem;">Logout</a>
        </div>

        <!-- Message Alert -->
        <?php if(isset($_SESSION['message'])): ?>
            <div style="padding: 15px; margin-bottom: 20px; border-radius: 10px; font-weight: bold; background: #d4edda; color: #155724; border: 1px solid #c3e6cb;">
                <?= $_SESSION['message']; ?>
            </div>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>

        <!-- Stats Row -->
        <div class="grid" style="grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 40px;">
            
            <!-- 1. Total Students (LINK ADDED HERE) -->
            <a href="admin-users.php" style="text-decoration: none; display: block;">
                <div class="card" style="background: var(--green-dark); color: white; transition: transform 0.2s; cursor: pointer;">
                    <h3><i class="fas fa-users"></i> Total Students</h3>
                    <p style="font-size: 2rem; font-weight: bold; color: white;">
                        <?php
                            // Total Students count
                            $query = "SELECT id FROM users WHERE role='student'";
                            $query_run = mysqli_query($conn, $query);
                            echo mysqli_num_rows($query_run);
                        ?>
                    </p>
                    <small style="color: #ddd;">Click to Manage Users</small>
                </div>
            </a>

            <!-- 2. Total Events -->
            <div class="card" style="background: #2c3e50; color: white;">
                <h3><i class="fas fa-calendar-check"></i> Total Events</h3>
                <p style="font-size: 2rem; font-weight: bold; color: white;">
                     <?php
                        // Total Events count
                        $event_query = "SELECT id FROM events";
                        $event_run = mysqli_query($conn, $event_query);
                        echo mysqli_num_rows($event_run);
                    ?>
                </p>
            </div>

            <!-- 3. Total Chapters -->
            <div class="card" style="background: #e67e22; color: white;">
                <h3><i class="fas fa-layer-group"></i> Total Chapters</h3> 
                <p style="font-size: 2rem; font-weight: bold; color: white;">
                    <?php
                        // Total Chapters count
                        $chapter_query = "SELECT id FROM chapters";
                        $chapter_run = mysqli_query($conn, $chapter_query);
                        echo mysqli_num_rows($chapter_run);
                    ?>
                </p>
            </div>
        </div>

        <h3 style="margin-bottom: 20px;">Manage Society</h3>
        <div class="grid" style="grid-template-columns: repeat(4, 1fr); gap: 20px;">
            
            <!-- 1. Events Button -->
            <a href="admin-add-event.php" style="text-decoration: none;">
                <div class="card" style="cursor: pointer; transition: 0.3s;">
                    <h3><i class="fas fa-plus-circle"></i> Add Event</h3>
                    <p>Create new events and announcements.</p>
                </div>
            </a>
            
            <!-- 2. Manage Chapters Button -->
            <a href="admin-manage-chapters.php" style="text-decoration: none;">
                <div class="card" style="cursor: pointer; transition: 0.3s; background: #c2e0c6;"> 
                    <h3><i class="fas fa-project-diagram"></i> Manage Chapters</h3>
                    <p>Add, edit, or remove society chapters/wings.</p>
                </div>
            </a>
            
            <!-- 3. Manage Nominations Button -->
            <a href="admin-nominations.php" style="text-decoration: none;">
                <div class="card" style="cursor: pointer; transition: 0.3s; background: #d1ecf1;">
                    <h3 style="color: #0c5460;"><i class="fas fa-users-cog"></i> Nominations</h3>
                    <p style="color: #0c5460;">Review and approve student nominations.</p>
                </div>
            </a>

           <!-- 4. Manage Gallery Button -->
            <a href="admin-gallery.php" style="text-decoration: none;">
                <div class="card" style="cursor: pointer; transition: 0.3s; background: #e2e6ea;">
                    <h3 style="color: #343a40;"><i class="fas fa-images"></i> Gallery</h3>
                    <p style="color: #343a40;">Upload event photos.</p>
                </div>
            </a>
        </div>
        
        <!-- Manage Existing Events (Delete Option) -->
        <!-- (Yeh wahi code hai jo maine pehle diya tha, lekin since ab list add-event page par hai, yahan se hata diya hai taake dashboard clean rahay) -->
        <!-- Agar aapko yahan wapis chahiye tou bata dena, magar abhi clean dashboard behtar hai -->
        
    </div>
</div>

<?php include 'footer.php'; ?>