<?php
session_start();
include('db.php');

// --- ADD CHAPTER ---
if(isset($_POST['add_chapter_btn']))
{
    $chapter_name = mysqli_real_escape_string($conn, $_POST['chapter_name']);
    $head_name = mysqli_real_escape_string($conn, $_POST['head_name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    
    // Check duplicate
    $check_query = "SELECT chapter_name FROM chapters WHERE chapter_name='$chapter_name' LIMIT 1";
    $check_run = mysqli_query($conn, $check_query);
    
    if(mysqli_num_rows($check_run) > 0)
    {
        $_SESSION['message'] = "Chapter Name already exists!";
        header("Location: admin-manage-chapters.php");
        exit(0);
    }

    $query = "INSERT INTO chapters (chapter_name, head_name, description) VALUES ('$chapter_name', '$head_name', '$description')";
    $query_run = mysqli_query($conn, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Chapter Added Successfully!";
        header("Location: admin-manage-chapters.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Something went wrong while adding chapter!";
        header("Location: admin-manage-chapters.php");
        exit(0);
    }
}

// --- DELETE CHAPTER ---
if(isset($_POST['delete_chapter_btn']))
{
    $chapter_id = mysqli_real_escape_string($conn, $_POST['chapter_id']);

    $query = "DELETE FROM chapters WHERE id='$chapter_id' ";
    $query_run = mysqli_query($conn, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Chapter Deleted Successfully!";
        header("Location: admin-manage-chapters.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Something went wrong!";
        header("Location: admin-manage-chapters.php");
        exit(0);
    }
}

// --- UPDATE CHAPTER ---
if(isset($_POST['update_chapter_btn']))
{
    $chapter_id = mysqli_real_escape_string($conn, $_POST['chapter_id']);
    $chapter_name = mysqli_real_escape_string($conn, $_POST['chapter_name']);
    $head_name = mysqli_real_escape_string($conn, $_POST['head_name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);

    $query = "UPDATE chapters SET chapter_name='$chapter_name', head_name='$head_name', description='$description' WHERE id='$chapter_id' ";
    $query_run = mysqli_query($conn, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Chapter Updated Successfully!";
        header("Location: admin-manage-chapters.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Something went wrong!";
        header("Location: admin-manage-chapters.php");
        exit(0);
    }
}
?>