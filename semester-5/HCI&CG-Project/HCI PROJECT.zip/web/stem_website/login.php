<?php 
session_start(); 

// --- 1. COOKIE LOGIC (Added) ---
$saved_email = "";
if(isset($_COOKIE['user_email']))
{
    $saved_email = $_COOKIE['user_email']; // Agar cookie hai tou email utha lo
}
// -------------------------------

include 'header.php'; 
?>

<div class="section" id="login">
  <div class="container" style="max-width: 500px; margin: 0 auto;">
    
    <div class="card" style="background: rgba(255,255,255,0.95); padding: 40px; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.1);">
      
      <!-- Back to Home -->
      <div style="text-align: left; margin-bottom: 20px;">
        <a href="index.php" style="text-decoration: none; color: var(--green-dark); font-weight: bold; display: inline-flex; align-items: center; gap: 8px;">
          <i class="fas fa-arrow-left"></i> Back to Home
        </a>
      </div>

      <h2 style="color: var(--green-dark); margin-bottom: 10px;">Welcome Back</h2>
      <p style="margin-bottom: 20px; color: #666;">Login with your Email and Password</p>

      <!-- MESSAGE ALERT -->
      <?php if(isset($_SESSION['message'])): ?>
        <div style="
            padding: 15px; margin-bottom: 20px; border-radius: 10px; font-weight: bold; text-align: center;
            background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb;
        ">
            <?= $_SESSION['message']; ?>
        </div>
        <?php unset($_SESSION['message']); ?>
      <?php endif; ?>

      <form action="login_code.php" method="POST">
        
        <div style="margin-bottom: 20px; text-align: left;">
          <label style="font-weight: 600; color: var(--green-dark);">Email Address</label>
          <!-- Value attribute mein saved_email dala hai -->
          <input type="email" name="email" value="<?= $saved_email; ?>" required 
                 style="width: 100%; padding: 12px; margin-top: 5px; border: 1px solid #ddd; border-radius: 10px; outline: none;">
        </div>

        <div style="margin-bottom: 15px; text-align: left;">
          <label style="font-weight: 600; color: var(--green-dark);">Password</label>
          <input type="password" name="password" required 
                 style="width: 100%; padding: 12px; margin-top: 5px; border: 1px solid #ddd; border-radius: 10px; outline: none;">
        </div>

        <!-- NEW: REMEMBER ME CHECKBOX -->
        <div style="margin-bottom: 25px; text-align: left; display: flex; align-items: center;">
            <input type="checkbox" name="remember_me" id="remember" style="width: 16px; height: 16px; cursor: pointer;">
            <label for="remember" style="margin-left: 8px; cursor: pointer; color: #555; font-size: 0.95rem;">Remember Me</label>
        </div>

        <button type="submit" name="login_btn" class="btn" style="width: 100%; font-size: 1.1rem;">
          Login Securely
        </button>

      </form>
      
      <p style="margin-top: 20px; font-size: 0.9rem;">
        Don't have a STEM ID? <a href="register.php" style="color: var(--green2); font-weight: bold;">Register here</a>
      </p>

    </div>
  </div>
</div>

<?php include 'footer.php'; ?>