<?php
session_start();
// Database connect karna zaroori hai list dikhane ke liye
include('db.php');

// Security Check
if(!isset($_SESSION['auth']) || $_SESSION['auth_user']['role'] != 'admin'){
    header("Location: login.php");
    exit(0);
}
include 'header.php';
?>

<div class="section" style="background: #f4f4f4; min-height: 100vh;">
    <div class="container" style="max-width: 900px; margin: 0 auto;">
        
        <!-- SECTION 1: ADD EVENT FORM -->
        <div class="card" style="background: white; padding: 40px; border-radius: 15px; text-align: left; margin-bottom: 40px;">
            
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2 style="margin: 0; color: var(--green-dark);">Add New Event</h2>
                <a href="admin-dashboard.php" class="btn-outline" style="padding: 8px 15px; text-decoration: none;">Back to Dashboard</a>
            </div>

            <?php if(isset($_SESSION['message'])): ?>
                <div style="padding: 10px; margin-bottom: 15px; background: #d4edda; color: #155724; border-radius: 5px;">
                    <?= $_SESSION['message']; ?>
                </div>
                <?php unset($_SESSION['message']); ?>
            <?php endif; ?>

            <form action="event_code.php" method="POST" enctype="multipart/form-data">
                
                <div style="margin-bottom: 20px;">
                    <label style="font-weight: bold;">Event Title</label>
                    <input type="text" name="title" required placeholder="e.g. Annual STEM Dinner" 
                           style="width: 100%; padding: 10px; margin-top: 5px; border: 1px solid #ccc; border-radius: 5px;">
                </div>

                <div style="display: flex; gap: 20px; margin-bottom: 20px;">
                    <div style="flex: 1;">
                        <label style="font-weight: bold;">Event Date</label>
                        <input type="date" name="event_date" required 
                               style="width: 100%; padding: 10px; margin-top: 5px; border: 1px solid #ccc; border-radius: 5px;">
                    </div>
                    <div style="flex: 1;">
                        <label style="font-weight: bold;">Venue</label>
                        <input type="text" name="venue" required placeholder="e.g. Auditorium" 
                               style="width: 100%; padding: 10px; margin-top: 5px; border: 1px solid #ccc; border-radius: 5px;">
                    </div>
                </div>

                <div style="margin-bottom: 20px;">
                    <label style="font-weight: bold;">Event Banner / Image</label>
                    <input type="file" name="event_image" required accept="image/*"
                           style="width: 100%; padding: 10px; margin-top: 5px; border: 1px solid #ccc; border-radius: 5px; background: #fafafa;">
                    <small style="color: #666;">Allowed formats: JPG, PNG, JPEG</small>
                </div>

                <div style="margin-bottom: 20px;">
                    <label style="font-weight: bold;">Description</label>
                    <textarea name="description" rows="4" required placeholder="Enter event details..." 
                              style="width: 100%; padding: 10px; margin-top: 5px; border: 1px solid #ccc; border-radius: 5px;"></textarea>
                </div>

                <button type="submit" name="add_event_btn" class="btn" style="width: 100%;">Save Event</button>

            </form>
        </div>

        <!-- SECTION 2: EXISTING EVENTS LIST (Table) -->
        <div class="card" style="background: white; padding: 25px; border-radius: 15px;">
            <h3 style="color: #333; margin-bottom: 15px; border-bottom: 2px solid #eee; padding-bottom: 10px;">Existing Events</h3>
            
            <table border="1" style="width: 100%; border-collapse: collapse; text-align: left; font-size: 0.95rem;">
                <thead>
                    <tr style="background: #f8f9fa; color: #333;">
                        <th style="padding: 12px; border: 1px solid #ddd;">Image</th>
                        <th style="padding: 12px; border: 1px solid #ddd;">Event Title</th>
                        <th style="padding: 12px; border: 1px solid #ddd;">Date</th>
                        <th style="padding: 12px; border: 1px solid #ddd;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $query = "SELECT * FROM events ORDER BY event_date DESC";
                    $query_run = mysqli_query($conn, $query);

                    if(mysqli_num_rows($query_run) > 0)
                    {
                        while($row = mysqli_fetch_assoc($query_run))
                        {
                            ?>
                            <tr>
                                <td style="padding: 10px; border: 1px solid #ddd; width: 80px; text-align: center;">
                                    <?php if($row['event_image']): ?>
                                        <img src="uploads/<?= $row['event_image']; ?>" alt="img" style="width: 50px; height: 50px; object-fit: cover; border-radius: 5px;">
                                    <?php else: ?>
                                        <span>No Img</span>
                                    <?php endif; ?>
                                </td>
                                <td style="padding: 10px; border: 1px solid #ddd; font-weight: bold;"><?= $row['title']; ?></td>
                                <td style="padding: 10px; border: 1px solid #ddd;"><?= $row['event_date']; ?></td>
                                <td style="padding: 10px; border: 1px solid #ddd;">
                                    <!-- Delete Button Form -->
                                    <form action="event_code.php" method="POST" onsubmit="return confirm('Are you sure you want to delete this event? This cannot be undone.');">
                                        <input type="hidden" name="delete_id" value="<?= $row['id']; ?>">
                                        <button type="submit" name="delete_event_btn" 
                                                style="background: #dc3545; color: white; border: none; padding: 6px 12px; cursor: pointer; border-radius: 4px; font-size: 0.85rem;">
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php
                        }
                    }
                    else
                    {
                        echo "<tr><td colspan='4' style='padding:15px; text-align:center; color:#777;'>No Events Found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>

    </div>
</div>

<?php include 'footer.php'; ?>