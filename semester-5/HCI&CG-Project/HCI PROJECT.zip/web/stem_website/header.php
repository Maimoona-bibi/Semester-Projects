<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>STEM Society | FJWU</title>
  
  <!-- Font Awesome for Icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

  <style>
    /* --- CSS Styles --- */
    
    :root {
      /* FJWU Theme Colors */
      --green1: #43e97b; 
      --green2: #168a53; 
      --green-dark: #0f5c36;
      --white: #ffffff;
      --glass-bg: rgba(255, 255, 255, 0.85);
      --glass-border: #b6f5d8;
      --shadow: 0 8px 32px 0 rgba(6, 23, 13, 0.15);
      --text-color: #333;
    }

    * { margin: 0; padding: 0; box-sizing: border-box; scroll-behavior: smooth; }

    body {
      font-family: 'Segoe UI', 'Poppins', sans-serif;
      background: linear-gradient(135deg, #f0fff4 0%, #dcfce7 100%);
      color: var(--text-color);
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }

    /* Navbar */
    .navbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 15px 5%;
      position: fixed;
      top: 0; left: 0; right: 0;
      background: rgba(255, 255, 255, 0.95);
      border-bottom: 3px solid var(--green2);
      box-shadow: 0 2px 15px rgba(0,0,0,0.1);
      z-index: 1000;
    }

    .navbar .logo {
      display: flex;
      align-items: center;
      font-size: 1.5rem;
      font-weight: 800;
      color: var(--green-dark);
      letter-spacing: 1px;
      text-transform: uppercase;
    }

    .logo-img {
      height: 50px;
      width: auto;
      margin-right: 15px;
      border-radius: 50%; 
      border: 2px solid var(--green1);
    }

    .navbar nav {
      display: flex;
      gap: 10px;
    }

    .navbar nav a {
      color: var(--green-dark);
      font-weight: 600;
      text-decoration: none;
      padding: 8px 20px;
      border-radius: 25px;
      transition: all 0.3s ease;
      font-size: 0.95rem;
    }

    .navbar nav a:hover {
      background: var(--green2);
      color: var(--white);
      transform: translateY(-2px);
    }

    /* Mobile Menu Button */
    .menu-toggle {
      display: none;
      font-size: 1.5rem;
      color: var(--green-dark);
      cursor: pointer;
    }

    /* Common Section Styles */
    .section {
      padding: 80px 8%;
      text-align: center;
    }

    .section h2 {
      font-size: 2.5rem;
      margin-bottom: 50px;
      color: var(--green-dark);
      position: relative;
      display: inline-block;
    }

    .section h2::after {
      content: '';
      display: block;
      width: 60%;
      height: 4px;
      background: var(--green1);
      margin: 10px auto 0;
      border-radius: 2px;
    }

    /* Hero Styles */
    .hero {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      text-align: center;
      padding: 120px 20px 60px;
      background-image: radial-gradient(var(--green1) 1px, transparent 1px);
      background-size: 30px 30px;
    }

    .hero-content {
      max-width: 800px;
      background: rgba(255, 255, 255, 0.9);
      padding: 40px;
      border-radius: 30px;
      box-shadow: var(--shadow);
      border: 1px solid var(--white);
      backdrop-filter: blur(10px);
    }

    .hero h1 {
      font-size: 3rem;
      font-weight: 800;
      margin-bottom: 20px;
      background: linear-gradient(to right, var(--green-dark), var(--green2));
      -webkit-background-clip: text;
      color: transparent;
      line-height: 1.2;
    }

    .hero-buttons {
      display: flex;
      gap: 20px;
      justify-content: center;
      flex-wrap: wrap;
      margin-top: 20px;
    }

    /* Button Styles */
    .btn {
      padding: 12px 35px;
      background: linear-gradient(90deg, var(--green2), var(--green1));
      color: var(--white);
      border: none;
      border-radius: 30px;
      font-weight: bold;
      font-size: 1rem;
      box-shadow: 0 4px 15px rgba(22, 138, 83, 0.3);
      cursor: pointer;
      text-decoration: none;
      transition: transform 0.2s, box-shadow 0.2s;
    }

    .btn:hover {
      transform: translateY(-3px);
      box-shadow: 0 8px 20px rgba(22, 138, 83, 0.4);
    }

    .btn-outline {
      background: transparent;
      color: var(--green-dark);
      border: 2px solid var(--green2);
    }

    .btn-outline:hover {
      background: var(--green2);
      color: var(--white);
    }

    /* Card Styles */
    .grid {
      display: grid;
      gap: 30px;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    }

    .card {
      background: var(--white);
      border-radius: 20px;
      padding: 30px;
      transition: all 0.3s ease;
      border: 1px solid #e1e1e1;
      text-align: left;
      position: relative;
      overflow: hidden;
      box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    }

    .card:hover {
      transform: translateY(-10px);
      box-shadow: 0 15px 30px rgba(0,0,0,0.1);
    }

    .card h3 {
      color: var(--green-dark);
      margin-bottom: 15px;
      font-size: 1.5rem;
      display: flex;
      align-items: center;
      gap: 10px;
    }

    /* Footer Styles */
    .footer {
      background: var(--green-dark);
      color: var(--white);
      text-align: center;
      padding: 40px 20px;
      margin-top: auto; /* Pushes footer to bottom if content is short */
    }

    /* Responsive */
    @media (max-width: 768px) {
      .navbar { padding: 15px 20px; }
      .navbar nav { display: none; }
      .menu-toggle { display: block; }
      .hero h1 { font-size: 2.2rem; }
    }
  </style>
</head>
<body>

  <!-- Navbar -->
  <div class="navbar">
    <div class="logo">
      <img src="https://cdn-icons-png.flaticon.com/512/2997/2997300.png" alt="STEM Logo" class="logo-img">
      STEM Society
    </div>
    
    <nav>
      <a href="index.php#features">Features</a>
      <a href="index.php#events">Events</a>
      <a href="index.php#gallery">Gallery</a>
      <a href="index.php#contact">Contact</a>
      <a href="login.php" class="btn-outline" style="padding: 5px 15px; border-radius: 20px; margin-left: 10px;">Login</a>
    </nav>
    
    <div class="menu-toggle">
      <i class="fas fa-bars"></i>
    </div>
  </div>