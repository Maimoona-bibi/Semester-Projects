<?php
session_start();
include('db.php');

// Security Check
if(!isset($_SESSION['auth']) || $_SESSION['auth_user']['role'] != 'admin'){
    header("Location: login.php");
    exit(0);
}

include 'header.php';
?>

<div class="section" style="background: #f4f4f4; padding-top: 120px; min-height: 100vh;">
    <div class="container" style="max-width: 1200px; margin: 0 auto; text-align: left;">
        
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
            <h2 style="margin: 0; color: var(--green-dark);">Manage Nominations</h2>
            <a href="admin-dashboard.php" class="btn-outline" style="padding: 8px 15px; text-decoration: none;">Back to Dashboard</a>
        </div>

        <!-- Message Alert -->
        <?php if(isset($_SESSION['message'])): ?>
            <div style="padding: 15px; margin-bottom: 20px; border-radius: 10px; font-weight: bold; background: #d4edda; color: #155724; border: 1px solid #c3e6cb;">
                <?= $_SESSION['message']; ?>
            </div>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>

        <div class="card" style="background: white; padding: 30px; border-radius: 15px; overflow-x: auto;">
            
            <table style="width: 100%; border-collapse: collapse; min-width: 800px;">
                <thead>
                    <tr style="background: var(--green-dark); color: white;">
                        <th style="padding: 12px;">ID</th>
                        <th style="padding: 12px;">Student Name</th>
                        <th style="padding: 12px;">Role Applied</th>
                        <th style="padding: 12px;">Manifesto</th>
                        <th style="padding: 12px;">Status</th>
                        <th style="padding: 12px;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        // Join users table to get student name
                        $query = "SELECT n.*, u.fullname, u.stem_id 
                                  FROM nominations n 
                                  JOIN users u ON n.user_id = u.id 
                                  ORDER BY n.id DESC";
                        $query_run = mysqli_query($conn, $query);

                        if(mysqli_num_rows($query_run) > 0)
                        {
                            while($row = mysqli_fetch_assoc($query_run))
                            {
                                ?>
                                <tr style="border-bottom: 1px solid #eee;">
                                    <td style="padding: 15px;"><?= $row['id']; ?></td>
                                    <td style="padding: 15px;">
                                        <strong><?= htmlspecialchars($row['fullname']); ?></strong><br>
                                        <small style="color: #777;"><?= htmlspecialchars($row['stem_id']); ?></small>
                                    </td>
                                    <td style="padding: 15px; font-weight: bold; color: var(--green-dark);">
                                        <?= $row['role_name']; ?>
                                    </td>
                                    <td style="padding: 15px;">
                                        <div style="max-height: 60px; overflow-y: auto; font-size: 0.9rem; color: #555;">
                                            <?= htmlspecialchars(substr($row['manifesto'], 0, 100)) . '...'; ?>
                                        </div>
                                    </td>
                                    <td style="padding: 15px;">
                                        <?php if($row['status'] == 'pending'): ?>
                                            <span style="background: #f0ad4e; color: white; padding: 5px 10px; border-radius: 15px; font-size: 0.8rem;">Pending</span>
                                        <?php elseif($row['status'] == 'approved'): ?>
                                            <span style="background: var(--green-dark); color: white; padding: 5px 10px; border-radius: 15px; font-size: 0.8rem;">Approved</span>
                                        <?php else: ?>
                                            <span style="background: #d9534f; color: white; padding: 5px 10px; border-radius: 15px; font-size: 0.8rem;">Rejected</span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="padding: 15px;">
                                        <form action="nomination_status.php" method="POST" style="display: flex; gap: 5px;">
                                            <input type="hidden" name="nomination_id" value="<?= $row['id']; ?>">
                                            
                                            <button type="submit" name="approve_btn" class="btn" style="padding: 5px 10px; font-size: 0.8rem; background: var(--green1);" title="Approve">
                                                <i class="fas fa-check"></i>
                                            </button>
                                            
                                            <button type="submit" name="reject_btn" class="btn" style="padding: 5px 10px; font-size: 0.8rem; background: #d9534f;" title="Reject">
                                                <i class="fas fa-times"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                <?php
                            }
                        }
                        else
                        {
                            echo "<tr><td colspan='6' style='text-align:center; padding:20px;'>No Nominations Found</td></tr>";
                        }
                    ?>
                </tbody>
            </table>

        </div>

    </div>
</div>

<?php include 'footer.php'; ?>