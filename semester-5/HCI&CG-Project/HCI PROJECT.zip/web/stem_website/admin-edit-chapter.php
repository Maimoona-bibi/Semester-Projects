<?php
session_start();
include('db.php');

// Security Check
if(!isset($_SESSION['auth']) || $_SESSION['auth_user']['role'] != 'admin'){
    header("Location: login.php");
    exit(0);
}

include 'header.php';
?>

<div class="section" style="background: #f4f4f4; padding-top: 100px; min-height: 100vh;">
    <div class="container" style="max-width: 800px; margin: 0 auto; text-align: left;">
        
        <div class="card" style="background: white; padding: 40px; border-radius: 15px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
                <h3 style="margin: 0; color: #2c3e50;">Edit Chapter</h3>
                <a href="admin-manage-chapters.php" class="btn-outline" style="text-decoration: none;">Back</a>
            </div>

            <?php
            // URL se ID lena
            if(isset($_GET['id']))
            {
                $chapter_id = mysqli_real_escape_string($conn, $_GET['id']);
                // Database se us ID ka data mangwana
                $query = "SELECT * FROM chapters WHERE id='$chapter_id' LIMIT 1";
                $query_run = mysqli_query($conn, $query);

                if(mysqli_num_rows($query_run) > 0)
                {
                    $chapter = mysqli_fetch_assoc($query_run);
                    ?>
                    <!-- Edit Form -->
                    <form action="chapter_code.php" method="POST">
                        <!-- Hidden ID bhejna zaroori hai taake backend ko pata ho kisko update karna hai -->
                        <input type="hidden" name="chapter_id" value="<?= $chapter['id']; ?>">

                        <div class="grid" style="grid-template-columns: 1fr 1fr; gap: 20px;">
                            <div style="margin-bottom: 15px;">
                                <label style="font-weight: bold;">Chapter Name</label>
                                <input type="text" name="chapter_name" value="<?= $chapter['chapter_name']; ?>" required 
                                    style="width: 100%; padding: 10px; margin-top: 5px; border: 1px solid #ccc; border-radius: 5px;">
                            </div>
                            <div style="margin-bottom: 15px;">
                                <label style="font-weight: bold;">Chapter Head Name</label>
                                <input type="text" name="head_name" value="<?= $chapter['head_name']; ?>"
                                    style="width: 100%; padding: 10px; margin-top: 5px; border: 1px solid #ccc; border-radius: 5px;">
                            </div>
                        </div>
                        <div style="margin-bottom: 20px;">
                            <label style="font-weight: bold;">Description</label>
                            <textarea name="description" rows="3"
                                    style="width: 100%; padding: 10px; margin-top: 5px; border: 1px solid #ccc; border-radius: 5px;"><?= $chapter['description']; ?></textarea>
                        </div>
                        
                        <!-- Update Button -->
                        <button type="submit" name="update_chapter_btn" class="btn" style="width: 100%;">Update Chapter</button>
                    </form>
                    <?php
                }
                else
                {
                    echo "<h4>No ID Found</h4>";
                }
            }
            else
            {
                echo "<h4>Something went wrong (No ID given)</h4>";
            }
            ?>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>