<?php
session_start();

// Session khatam karo
session_destroy();
unset($_SESSION['auth']);
unset($_SESSION['auth_user']);

$_SESSION['message'] = "Logged out successfully";
header("Location: login.php");
exit(0);
?>