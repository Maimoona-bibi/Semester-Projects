<?php
session_start();
include('db.php');

// Security Check
if(!isset($_SESSION['auth']) || $_SESSION['auth_user']['role'] != 'admin'){
    header("Location: login.php");
    exit(0);
}
include 'header.php';
?>

<div class="section" style="background: #f4f4f4; padding-top: 100px; min-height: 100vh;">
    <div class="container" style="max-width: 1200px; margin: 0 auto; text-align: left;">
        
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
            <h2 style="margin: 0; color: var(--green-dark);">Manage Chapters</h2>
            <a href="admin-dashboard.php" class="btn-outline" style="padding: 8px 15px; text-decoration: none;">Back to Dashboard</a>
        </div>

        <!-- Message Alert -->
        <?php if(isset($_SESSION['message'])): ?>
            <div style="padding: 15px; margin-bottom: 20px; border-radius: 10px; font-weight: bold; background: #d4edda; color: #155724; border: 1px solid #c3e6cb;">
                <?= $_SESSION['message']; ?>
            </div>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>

        <!-- Add Chapter Form -->
        <div class="card" style="background: white; padding: 30px; border-radius: 15px; margin-bottom: 40px;">
            <h3 style="margin-bottom: 20px; color: #2c3e50;"><i class="fas fa-plus-square"></i> Add New Chapter</h3>
            <form action="chapter_code.php" method="POST">
                <div class="grid" style="grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div style="margin-bottom: 15px;">
                        <label style="font-weight: bold;">Chapter Name (e.g., GGDGC, MLSA)</label>
                        <input type="text" name="chapter_name" required 
                               style="width: 100%; padding: 10px; margin-top: 5px; border: 1px solid #ccc; border-radius: 5px;">
                    </div>
                    <div style="margin-bottom: 15px;">
                        <label style="font-weight: bold;">Chapter Head Name</label>
                        <input type="text" name="head_name" placeholder="Optional"
                               style="width: 100%; padding: 10px; margin-top: 5px; border: 1px solid #ccc; border-radius: 5px;">
                    </div>
                </div>
                <div style="margin-bottom: 20px;">
                    <label style="font-weight: bold;">Description</label>
                    <textarea name="description" rows="2" placeholder="Brief details about the chapter"
                              style="width: 100%; padding: 10px; margin-top: 5px; border: 1px solid #ccc; border-radius: 5px;"></textarea>
                </div>
                <button type="submit" name="add_chapter_btn" class="btn" style="width: 100%;">Save Chapter</button>
            </form>
        </div>

        <!-- Chapter List Table -->
        <div class="card" style="background: white; padding: 30px; border-radius: 15px;">
            <h3 style="margin-bottom: 20px; color: #2c3e50;"><i class="fas fa-list-alt"></i> Existing Chapters</h3>
            
            <table style="width: 100%; border-collapse: collapse;">
                <thead>
                    <tr style="background: var(--green-dark); color: white;">
                        <th style="padding: 12px; border: 1px solid #ddd; text-align: left;">ID</th>
                        <th style="padding: 12px; border: 1px solid #ddd; text-align: left;">Name</th>
                        <th style="padding: 12px; border: 1px solid #ddd; text-align: left;">Head</th>
                        <th style="padding: 12px; border: 1px solid #ddd; text-align: left;">Description</th>
                        <th style="padding: 12px; border: 1px solid #ddd; text-align: center;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $chapters_query = "SELECT * FROM chapters ORDER BY chapter_name ASC";
                        $chapters_run = mysqli_query($conn, $chapters_query);

                        if(mysqli_num_rows($chapters_run) > 0)
                        {
                            while($chapter = mysqli_fetch_assoc($chapters_run))
                            {
                                ?>
                                <tr style="background: #f9f9f9; transition: background 0.3s;">
                                    <td style="padding: 12px; border: 1px solid #eee;"><?= $chapter['id']; ?></td>
                                    <td style="padding: 12px; border: 1px solid #eee; font-weight: bold;"><?= $chapter['chapter_name']; ?></td>
                                    <td style="padding: 12px; border: 1px solid #eee;"><?= $chapter['head_name'] ? $chapter['head_name'] : 'N/A'; ?></td>
                                    <td style="padding: 12px; border: 1px solid #eee;"><?= $chapter['description']; ?></td>
                                    <td style="padding: 12px; border: 1px solid #eee; text-align: center;">
                                        
                                        <!-- Edit Button (Link to Edit Page) -->
                                        <a href="admin-edit-chapter.php?id=<?= $chapter['id']; ?>" class="btn-outline" style="padding: 5px 10px; font-size: 0.8rem; margin-right: 5px; text-decoration: none; display: inline-block;">Edit</a>
                                        
                                        <!-- Delete Button (Form) -->
                                        <form action="chapter_code.php" method="POST" style="display: inline-block;" onsubmit="return confirm('Are you sure you want to delete this Chapter?');">
                                            <input type="hidden" name="chapter_id" value="<?= $chapter['id']; ?>">
                                            <button type="submit" name="delete_chapter_btn" class="btn" style="background: #dc3545; padding: 5px 10px; font-size: 0.8rem;">Delete</button>
                                        </form>

                                    </td>
                                </tr>
                                <?php
                            }
                        }
                        else
                        {
                            ?>
                            <tr style="background: #fff;"><td colspan="5" style="padding: 20px; text-align: center; color: #777;">No Chapters Added Yet.</td></tr>
                            <?php
                        }
                    ?>
                </tbody>
            </table>

        </div>

    </div>
</div>

<?php include 'footer.php'; ?>