<?php
session_start();
include('db.php'); 

if(isset($_POST['login_btn'])) {

    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    
    // Query to check user credentials using Email
    $login_query = "SELECT * FROM users WHERE email='$email' LIMIT 1";
    $login_run = mysqli_query($conn, $login_query);

    if($login_run && mysqli_num_rows($login_run) > 0) {
        $user_data = mysqli_fetch_assoc($login_run);
        
        $db_password = $user_data['password'];
        $role = $user_data['role'] ?? 'student';
        
        // --- HYBRID PASSWORD CHECK (KEPT AS IS) ---
        $check_password = false;

        if (password_verify($password, $db_password)) {
            // Agar password Encrypted (Hash) hai (Admin ke liye)
            $check_password = true;
        } elseif ($password === $db_password) {
            // Agar password Simple Text hai (New Student ke liye)
            $check_password = true;
        }
        // ----------------------------------------

        if ($check_password) {
            
            // Storing all necessary data in session
            $_SESSION['auth'] = true;
            $_SESSION['auth_user'] = [
                'user_id' => $user_data['id'],
                'name' => $user_data['fullname'] ?? 'N/A',
                'reg_no' => $user_data['stem_id'] ?? 'N/A',
                'role' => $role,
                'semester' => $user_data['semester'] ?? 'N/A', 
                'chapter_id' => $user_data['chapter_id'] ?? null,
            ];

            // --- NEW: COOKIE LOGIC HERE ---
            if(isset($_POST['remember_me']))
            {
                // Cookie Set (30 Days)
                setcookie('user_email', $email, time() + (86400 * 30), "/");
            }
            else
            {
                // Cookie Delete (Agar untick kiya ho)
                if(isset($_COOKIE['user_email']))
                {
                    setcookie('user_email', "", time() - 3600, "/");
                }
            }
            // ------------------------------

            $_SESSION['message'] = "Login Successful. Welcome back!";

            // Redirect based on role
            if ($role === 'student') {
                header("Location: student-dashboard.php");
            } elseif ($role === 'admin') {
                header("Location: admin-dashboard.php");
            } else {
                header("Location: index.php"); 
            }
            exit(0);

        } else {
            $_SESSION['message'] = "Invalid Password. Please try again.";
            header("Location: login.php");
            exit(0);
        }
    } else {
        $_SESSION['message'] = "User not found with this Email.";
        header("Location: login.php");
        exit(0);
    }
} 
else 
{
    $_SESSION['message'] = "Access Denied. Please login.";
    header("Location: login.php");
    exit(0);
}
?>