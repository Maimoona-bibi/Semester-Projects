<?php
session_start();
include('db.php');

// --- 1. ADD EVENT LOGIC ---
if(isset($_POST['add_event_btn']))
{
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $date = mysqli_real_escape_string($conn, $_POST['event_date']);
    $venue = mysqli_real_escape_string($conn, $_POST['venue']);
    $desc = mysqli_real_escape_string($conn, $_POST['description']);

    // Image Upload Logic
    $image_name = $_FILES['event_image']['name'];
    
    // Image ko unique naam dena taake overwrite na ho
    $image_extension = pathinfo($image_name, PATHINFO_EXTENSION);
    $filename = time() . '.' . $image_extension;

    // Database Query
    $query = "INSERT INTO events (title, event_date, venue, description, event_image) VALUES ('$title', '$date', '$venue', '$desc', '$filename')";
    $query_run = mysqli_query($conn, $query);

    if($query_run)
    {
        // Image ko folder mein move karna
        move_uploaded_file($_FILES['event_image']['tmp_name'], 'uploads/'.$filename);

        $_SESSION['message'] = "Event Added Successfully!";
        header("Location: admin-dashboard.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Something went wrong!";
        header("Location: admin-add-event.php");
        exit(0);
    }
}

// --- 2. DELETE EVENT LOGIC (New) ---
if(isset($_POST['delete_event_btn']))
{
    $event_id = mysqli_real_escape_string($conn, $_POST['delete_id']);

    // Step A: Pehle check karein ke Image konsi hai (Taake delete kar sakein)
    $check_query = "SELECT event_image FROM events WHERE id='$event_id' ";
    $check_run = mysqli_query($conn, $check_query);
    $data = mysqli_fetch_assoc($check_run);
    
    $image_to_delete = $data['event_image'];

    // Step B: Database se Delete karna
    $query = "DELETE FROM events WHERE id='$event_id' ";
    $query_run = mysqli_query($conn, $query);

    if($query_run)
    {
        // Step C: Agar image thi, tou folder se bhi delete kar do
        if($image_to_delete != NULL)
        {
            if(file_exists('uploads/'.$image_to_delete))
            {
                unlink('uploads/'.$image_to_delete); // Yeh command file delete karti hai
            }
        }

        $_SESSION['message'] = "Event Deleted Successfully";
        header("Location: admin-dashboard.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Something went wrong during deletion";
        header("Location: admin-dashboard.php");
        exit(0);
    }
}
?>