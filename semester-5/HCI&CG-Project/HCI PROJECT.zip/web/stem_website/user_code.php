<?php
session_start();
include('db.php');

// Security Check
if(!isset($_SESSION['auth']) || $_SESSION['auth_user']['role'] != 'admin'){
    header("Location: login.php");
    exit(0);
}

// --- DELETE STUDENT LOGIC ---
if(isset($_POST['delete_student_btn']))
{
    $user_id = mysqli_real_escape_string($conn, $_POST['delete_id']);

    // Database se user ko urra dein
    $query = "DELETE FROM users WHERE id='$user_id' ";
    $query_run = mysqli_query($conn, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Student Deleted Successfully";
        header("Location: admin-users.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Something went wrong! Could not delete.";
        header("Location: admin-users.php");
        exit(0);
    }
}

// Agar koi direct access karne ki koshish kare
header("Location: admin-dashboard.php");
exit(0);
?>