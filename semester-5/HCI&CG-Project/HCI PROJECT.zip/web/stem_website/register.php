<?php 
session_start(); 
include('db.php'); // Database connection zaroori hai chapters fetch karne ke liye

// Agar user pehle se logged in hai, toh dashboard par bhej do
if(isset($_SESSION['auth'])){
    if($_SESSION['auth_user']['role'] == 'student'){
        header("Location: student-dashboard.php");
    } else {
        header("Location: admin-dashboard.php");
    }
    exit(0);
}

// --- CHAPTERS FETCHING LOGIC ---
$chapters_query = "SELECT * FROM chapters";
$chapters_run = mysqli_query($conn, $chapters_query);

include 'header.php'; 
?>

<!-- Main Section with Background Styling matching Home Page -->
<div class="section" id="register" style="min-height: 80vh; display: flex; align-items: center; justify-content: center; padding-top: 120px;">
  
  <!-- Glass Container for Form -->
  <div class="container glass" style="width: 100%; max-width: 600px; text-align: center;">
    
    <h2 style="color: var(--green-dark); margin-bottom: 10px;">Join STEM Society</h2>
    <p style="margin-bottom: 30px; color: #666;">Create your account. Your STEM ID will be generated automatically.</p>

    <!-- MESSAGE ALERT -->
    <?php if(isset($_SESSION['message'])): ?>
      <div style="
          padding: 15px; margin-bottom: 20px; border-radius: 10px; font-weight: bold;
          background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb;
      ">
          <?= $_SESSION['message']; ?>
      </div>
      <?php unset($_SESSION['message']); ?>
    <?php endif; ?>

    <form action="register_code.php" method="POST">
      
      <!-- Full Name -->
      <div style="margin-bottom: 20px; text-align: left;">
        <label style="font-weight: 600; color: var(--green-dark);">Full Name</label>
        <input type="text" name="name" required placeholder="e.g. Fatima Ali"
               style="width: 100%; padding: 12px; margin-top: 5px; border: 1px solid #b6f5d8; border-radius: 10px; outline: none; background: rgba(255,255,255,0.9);">
      </div>

      <!-- Email -->
      <div style="margin-bottom: 20px; text-align: left;">
        <label style="font-weight: 600; color: var(--green-dark);">Email Address</label>
        <input type="email" name="email" required placeholder="e.g. fatima@fjwu.edu.pk"
               style="width: 100%; padding: 12px; margin-top: 5px; border: 1px solid #b6f5d8; border-radius: 10px; outline: none; background: rgba(255,255,255,0.9);">
      </div>

      <!-- STEM ID Input REMOVED (It is now auto-generated) -->

      <div style="display: flex; gap: 20px; margin-bottom: 20px;">
          
          <!-- Semester Dropdown -->
          <div style="flex: 1; text-align: left;">
            <label style="font-weight: 600; color: var(--green-dark);">Semester</label>
            <select name="semester" required 
                    style="width: 100%; padding: 12px; margin-top: 5px; border: 1px solid #b6f5d8; border-radius: 10px; outline: none; background: rgba(255,255,255,0.9);">
                <option value="">Select</option>
                <?php for($i=1; $i<=8; $i++): ?>
                    <option value="<?= $i ?>"><?= $i ?>th</option>
                <?php endfor; ?>
            </select>
          </div>

          <!-- Chapter Dropdown (Dynamic Database Fetching) -->
          <div style="flex: 1; text-align: left;">
            <label style="font-weight: 600; color: var(--green-dark);">Chapter</label>
            <select name="chapter_id" required 
                    style="width: 100%; padding: 12px; margin-top: 5px; border: 1px solid #b6f5d8; border-radius: 10px; outline: none; background: rgba(255,255,255,0.9);">
                <option value="">Select Chapter</option>
                <?php 
                if(mysqli_num_rows($chapters_run) > 0) {
                    while($row = mysqli_fetch_assoc($chapters_run)) {
                        // Using ID as value, Name as display
                        echo '<option value="'.$row['id'].'">'.$row['chapter_name'].'</option>';
                    }
                } else {
                    echo '<option value="">No Chapters Available</option>';
                }
                ?>
            </select>
          </div>

      </div>

      <!-- Password -->
      <div style="margin-bottom: 30px; text-align: left;">
        <label style="font-weight: 600; color: var(--green-dark);">Password</label>
        <input type="password" name="password" required placeholder="Create a password"
               style="width: 100%; padding: 12px; margin-top: 5px; border: 1px solid #b6f5d8; border-radius: 10px; outline: none; background: rgba(255,255,255,0.9);">
      </div>

      <button type="submit" name="register_btn" class="btn" style="width: 100%; font-size: 1.1rem;">
        Create Account
      </button>

    </form>
    
    <p style="margin-top: 20px; font-size: 0.9rem;">
      Already registered? <a href="login.php" style="color: var(--green2); font-weight: bold;">Login here</a>
    </p>

  </div>
</div>

<?php include 'footer.php'; ?>