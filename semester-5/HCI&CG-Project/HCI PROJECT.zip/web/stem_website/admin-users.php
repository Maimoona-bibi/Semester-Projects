<?php
session_start();
include('db.php');

// Security Check
if(!isset($_SESSION['auth']) || $_SESSION['auth_user']['role'] != 'admin'){
    $_SESSION['message'] = "Authorized Access Only";
    header("Location: login.php");
    exit(0);
}

include('header.php');
?>

<div class="section" style="padding-top: 120px; min-height: 100vh; background: #f4f4f4;">
    <div class="container" style="max-width: 1100px; margin: 0 auto;">

        <div class="card" style="background: white; padding: 30px; border-radius: 15px; box-shadow: 0 4px 10px rgba(0,0,0,0.05);">
            
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h3 style="margin: 0; color: var(--green-dark);">Registered Students</h3>
                <a href="admin-dashboard.php" class="btn-outline" style="text-decoration: none; padding: 8px 15px;">Back to Dashboard</a>
            </div>

            <!-- Message Alert -->
            <?php if(isset($_SESSION['message'])): ?>
                <div style="padding: 15px; margin-bottom: 20px; background: #dff0d8; color: #3c763d; border: 1px solid #d6e9c6; border-radius: 5px;">
                    <?= $_SESSION['message']; ?>
                </div>
                <?php unset($_SESSION['message']); ?>
            <?php endif; ?>

            <div style="overflow-x: auto;">
                <table border="1" style="width: 100%; border-collapse: collapse; text-align: left; font-size: 0.95rem;">
                    <thead>
                        <tr style="background: #f8f9fa; color: #333;">
                            <th style="padding: 12px; border: 1px solid #ddd;">ID</th>
                            <th style="padding: 12px; border: 1px solid #ddd;">Full Name</th>
                            <th style="padding: 12px; border: 1px solid #ddd;">STEM ID (Reg No)</th>
                            <th style="padding: 12px; border: 1px solid #ddd;">Email</th>
                            <th style="padding: 12px; border: 1px solid #ddd;">Dept / Sem</th>
                            <th style="padding: 12px; border: 1px solid #ddd;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Sirf 'student' role walay users fetch karein
                        $query = "SELECT * FROM users WHERE role='student' ORDER BY id DESC";
                        $query_run = mysqli_query($conn, $query);

                        if(mysqli_num_rows($query_run) > 0)
                        {
                            while($row = mysqli_fetch_assoc($query_run))
                            {
                                ?>
                                <tr>
                                    <td style="padding: 10px; border: 1px solid #ddd;"><?= $row['id']; ?></td>
                                    <td style="padding: 10px; border: 1px solid #ddd; font-weight: bold;"><?= $row['fullname']; ?></td>
                                    <td style="padding: 10px; border: 1px solid #ddd;"><?= $row['stem_id']; ?></td>
                                    <td style="padding: 10px; border: 1px solid #ddd;"><?= $row['email']; ?></td>
                                    <td style="padding: 10px; border: 1px solid #ddd;">
                                        <?= $row['department']; ?> (Sem <?= $row['semester']; ?>)
                                    </td>
                                    <td style="padding: 10px; border: 1px solid #ddd;">
                                        <!-- Delete Button Form -->
                                        <form action="user_code.php" method="POST" onsubmit="return confirm('Are you sure you want to delete this student? Access will be removed immediately.');">
                                            <input type="hidden" name="delete_id" value="<?= $row['id']; ?>">
                                            <button type="submit" name="delete_student_btn" 
                                                    style="background: #dc3545; color: white; border: none; padding: 6px 12px; cursor: pointer; border-radius: 4px; font-size: 0.85rem;">
                                                <i class="fas fa-trash"></i> Delete
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                <?php
                            }
                        }
                        else
                        {
                            echo "<tr><td colspan='6' style='text-align:center; padding: 20px;'>No Students Registered Yet</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</div>

<?php include('footer.php'); ?>