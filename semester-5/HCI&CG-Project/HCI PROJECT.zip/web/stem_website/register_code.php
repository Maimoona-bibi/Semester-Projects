<?php
session_start();
include('db.php');

if(isset($_POST['register_btn'])) {
    
    // 1. Inputs ko clean aur escape karein
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $semester = mysqli_real_escape_string($conn, $_POST['semester']);
    $chapter_id = mysqli_real_escape_string($conn, $_POST['chapter_id']);

    // --- AUTOMATIC STEM ID GENERATION ---
    // Format: STEM-25-XXXX
    $year = date('y'); // Get last two digits of year (e.g., 25)
    $random_number = rand(1000, 9999); // Random 4 digit number
    $stem_id = "STEM-" . $year . "-" . $random_number;

    // Check karein ki ye ID pehle se exist to nahi karti (Rare Case)
    $check_id = "SELECT stem_id FROM users WHERE stem_id='$stem_id'";
    $run_check = mysqli_query($conn, $check_id);
    
    if(mysqli_num_rows($run_check) > 0) {
        // Agar same ID nikal aaye, to ek baar phir generate karein
        $random_number = rand(1000, 9999);
        $stem_id = "STEM-" . $year . "-" . $random_number;
    }
    // ------------------------------------

    // 2. Check karein ki email pehle se maujood toh nahi hai
    $check_query = "SELECT * FROM users WHERE email='$email' LIMIT 1";
    $check_run = mysqli_query($conn, $check_query);

    if (mysqli_num_rows($check_run) > 0) {
        $_SESSION['message'] = "Registration Failed: Email Address already exists. Please login.";
        header("Location: register.php");
        exit(0);
    } 
    
    // 3. Agar sab theek hai, toh data insert karein
    else {
        // Columns must match your database table
        $register_query = "INSERT INTO users (fullname, email, password, stem_id, semester, chapter_id, role) 
                           VALUES ('$name', '$email', '$password', '$stem_id', '$semester', '$chapter_id', 'student')";
        
        $register_run = mysqli_query($conn, $register_query);

        if ($register_run) {
            // Success Message with generated ID shown to user
            $_SESSION['message'] = "Registration Successful! Your new STEM ID is: " . $stem_id;
            header("Location: login.php");
            exit(0);
        } else {
            // Database Error
            $_SESSION['message'] = "Registration Failed: Something went wrong.";
            header("Location: register.php");
            exit(0);
        }
    }
} else {
    // Direct access check
    header("Location: register.php");
    exit(0);
}
?>