<?php
session_start();
include('db.php');
// REMOVED: include('header.php'); from here (Yeh neeche jayega)

// --- 1. Security Check ---
if(!isset($_SESSION['auth']) || $_SESSION['auth_user']['role'] != 'student'){
    $_SESSION['message'] = "Access Denied.";
    header("Location: login.php");
    exit(0);
}

$current_user_id = $_SESSION['auth_user']['user_id'];

// --- 2. Update Logic (Form Submit hone par) ---
// Yeh hissa ab Header load hone se pehle chalega, is liye Redirect error nahi dega.
if(isset($_POST['update_profile_btn']))
{
    $fullname = mysqli_real_escape_string($conn, $_POST['fullname']);
    $department = mysqli_real_escape_string($conn, $_POST['department']);
    $semester = mysqli_real_escape_string($conn, $_POST['semester']);
    
    $new_password = mysqli_real_escape_string($conn, $_POST['password']);
    $confirm_password = mysqli_real_escape_string($conn, $_POST['confirm_password']);

    // Password Update Logic
    $password_query_part = "";
    
    if($new_password != "")
    {
        if($new_password == $confirm_password)
        {
            // Simple hashing use kar rahay hain jaisa aapne pehle kiya tha
            $hashed_password = $new_password; 
            $password_query_part = ", password='$hashed_password'";
        }
        else
        {
            $_SESSION['message'] = "New Password and Confirm Password do not match!";
            header("Location: student-profile-edit.php");
            exit(0);
        }
    }

    // Database Update Query
    $update_query = "UPDATE users SET fullname='$fullname', department='$department', semester='$semester' $password_query_part WHERE id='$current_user_id'";
    $update_run = mysqli_query($conn, $update_query);

    if($update_run)
    {
        // Session Update
        $_SESSION['auth_user']['name'] = $fullname;
        $_SESSION['auth_user']['semester'] = $semester;

        $_SESSION['message'] = "Profile Updated Successfully!";
        header("Location: student-dashboard.php"); // Ab yeh line error nahi degi
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Something went wrong!";
        header("Location: student-profile-edit.php");
        exit(0);
    }
}

// --- 3. Fetch Current Data ---
$user_query = "SELECT * FROM users WHERE id='$current_user_id' LIMIT 1";
$user_run = mysqli_query($conn, $user_query);

if(mysqli_num_rows($user_run) > 0)
{
    $user_data = mysqli_fetch_assoc($user_run);
}
else
{
    echo "<h4>User not found!</h4>";
    exit(0);
}

// ADDED HERE: Ab hum Header include karenge jab saara redirection logic check ho chuka hai
include('header.php');
?>

<div class="section" style="padding-top: 120px; min-height: 80vh; background: #f9f9f9;">
    <div class="container" style="max-width: 700px; margin: 0 auto;">
        
        <div class="card" style="background: white; padding: 40px; border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.05);">
            
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
                <h2 style="margin: 0; color: var(--green-dark);">Edit Profile</h2>
                <a href="student-dashboard.php" class="btn" style="background: #ccc; color: #333; padding: 8px 15px; font-size: 0.9rem; text-decoration: none;">Cancel</a>
            </div>

            <!-- Message Alert -->
            <?php if(isset($_SESSION['message'])): ?>
                <div style="padding: 15px; margin-bottom: 20px; background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; border-radius: 5px;">
                    <?= $_SESSION['message']; ?>
                </div>
                <?php unset($_SESSION['message']); ?>
            <?php endif; ?>

            <form action="student-profile-edit.php" method="POST">
                
                <!-- Full Name -->
                <div style="margin-bottom: 20px;">
                    <label style="font-weight: bold; display: block; margin-bottom: 5px;">Full Name</label>
                    <input type="text" name="fullname" value="<?= $user_data['fullname']; ?>" required 
                           style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 5px;">
                </div>

                <!-- STEM ID (Read Only) -->
                <div style="margin-bottom: 20px;">
                    <label style="font-weight: bold; display: block; margin-bottom: 5px;">STEM ID (Cannot be changed)</label>
                    <input type="text" value="<?= $user_data['stem_id']; ?>" readonly 
                           style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 5px; background: #e9ecef; color: #666;">
                </div>

                <div style="display: flex; gap: 20px; margin-bottom: 20px;">
                    <!-- Department -->
                    <div style="flex: 1;">
                        <label style="font-weight: bold; display: block; margin-bottom: 5px;">Department</label>
                        <input type="text" name="department" value="<?= $user_data['department']; ?>" required 
                               style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 5px;">
                    </div>
                    <!-- Semester -->
                    <div style="flex: 1;">
                        <label style="font-weight: bold; display: block; margin-bottom: 5px;">Current Semester</label>
                        <input type="number" name="semester" value="<?= $user_data['semester']; ?>" min="1" max="8" required 
                               style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 5px;">
                    </div>
                </div>

                <hr style="margin: 30px 0; border: 0; border-top: 1px solid #eee;">
                
                <h4 style="margin-bottom: 15px; color: #555;">Change Password <small style="font-weight: normal; font-size: 0.8rem;">(Leave blank to keep current)</small></h4>

                <div style="display: flex; gap: 20px; margin-bottom: 20px;">
                    <!-- New Password -->
                    <div style="flex: 1;">
                        <label style="font-weight: bold; display: block; margin-bottom: 5px;">New Password</label>
                        <input type="password" name="password" placeholder="New Password" 
                               style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 5px;">
                    </div>
                    <!-- Confirm Password -->
                    <div style="flex: 1;">
                        <label style="font-weight: bold; display: block; margin-bottom: 5px;">Confirm Password</label>
                        <input type="password" name="confirm_password" placeholder="Confirm Password" 
                               style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 5px;">
                    </div>
                </div>

                <button type="submit" name="update_profile_btn" class="btn" style="width: 100%; padding: 12px; font-size: 1rem;">Update Profile</button>

            </form>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>