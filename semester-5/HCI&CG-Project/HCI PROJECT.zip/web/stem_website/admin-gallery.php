<?php
session_start();
include('db.php');

// Security Check
if(!isset($_SESSION['auth']) || $_SESSION['auth_user']['role'] != 'admin'){
    header("Location: login.php");
    exit(0);
}

// --- HANDLE IMAGE UPLOAD ---
if(isset($_POST['upload_btn']))
{
    $caption = mysqli_real_escape_string($conn, $_POST['caption']);
    $image = $_FILES['image']['name'];
    $image_temp = $_FILES['image']['tmp_name'];

    // Rename image to avoid duplicates (time + original name)
    $new_image_name = time() . "_" . $image;
    $target = "uploads/" . $new_image_name;

    if(move_uploaded_file($image_temp, $target))
    {
        $query = "INSERT INTO gallery_images (image_path, caption) VALUES ('$new_image_name', '$caption')";
        mysqli_query($conn, $query);
        $_SESSION['message'] = "Image Uploaded Successfully!";
    }
    else
    {
        $_SESSION['message'] = "Failed to upload image. Make sure 'uploads' folder exists.";
    }
    header("Location: admin-gallery.php");
    exit(0);
}

// --- HANDLE DELETE ---
if(isset($_POST['delete_btn']))
{
    $id = $_POST['image_id'];
    $path = $_POST['image_path'];

    // Delete from folder
    if(file_exists("uploads/".$path)) {
        unlink("uploads/".$path);
    }

    // Delete from database
    $query = "DELETE FROM gallery_images WHERE id='$id'";
    mysqli_query($conn, $query);
    
    $_SESSION['message'] = "Image Deleted!";
    header("Location: admin-gallery.php");
    exit(0);
}

include 'header.php';
?>

<div class="section" style="background: #f4f4f4; padding-top: 120px; min-height: 100vh;">
    <div class="container" style="max-width: 1000px; margin: 0 auto;">
        
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
            <h2 style="margin: 0; color: var(--green-dark);">Manage Gallery</h2>
            <a href="admin-dashboard.php" class="btn-outline" style="padding: 8px 15px; text-decoration: none;">Back</a>
        </div>

        <?php if(isset($_SESSION['message'])): ?>
            <div style="padding: 15px; margin-bottom: 20px; border-radius: 10px; font-weight: bold; background: #d4edda; color: #155724; border: 1px solid #c3e6cb;">
                <?= $_SESSION['message']; ?>
            </div>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>

        <!-- Upload Form -->
        <div class="card" style="background: white; padding: 30px; border-radius: 15px; margin-bottom: 30px;">
            <h3>Upload New Photo</h3>
            <form action="admin-gallery.php" method="POST" enctype="multipart/form-data" style="margin-top: 15px; display: flex; gap: 10px; align-items: flex-end;">
                <div style="flex: 1;">
                    <label>Select Image</label>
                    <input type="file" name="image" required class="form-control" style="padding: 10px; border: 1px solid #ddd; width: 100%; border-radius: 5px;">
                </div>
                <div style="flex: 1;">
                    <label>Caption (Optional)</label>
                    <input type="text" name="caption" placeholder="e.g. Tech Event 2025" style="padding: 11px; border: 1px solid #ddd; width: 100%; border-radius: 5px;">
                </div>
                <button type="submit" name="upload_btn" class="btn" style="height: 45px;">Upload</button>
            </form>
        </div>

        <!-- Existing Images Grid -->
        <h3>Current Gallery</h3>
        <div class="grid" style="grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 20px;">
            <?php
                $query = "SELECT * FROM gallery_images ORDER BY id DESC";
                $run = mysqli_query($conn, $query);
                if(mysqli_num_rows($run) > 0) {
                    while($row = mysqli_fetch_assoc($run)) {
                        ?>
                        <div class="card" style="padding: 10px;">
                            <img src="uploads/<?= $row['image_path']; ?>" style="width: 100%; height: 150px; object-fit: cover; border-radius: 10px;">
                            <p style="margin: 10px 0; font-size: 0.9rem; font-weight: bold;"><?= $row['caption']; ?></p>
                            <form action="admin-gallery.php" method="POST">
                                <input type="hidden" name="image_id" value="<?= $row['id']; ?>">
                                <input type="hidden" name="image_path" value="<?= $row['image_path']; ?>">
                                <button type="submit" name="delete_btn" class="btn" style="background: #dc3545; width: 100%; padding: 5px; font-size: 0.8rem;">Delete</button>
                            </form>
                        </div>
                        <?php
                    }
                } else {
                    echo "<p>No images found.</p>";
                }
            ?>
        </div>

    </div>
</div>

<?php include 'footer.php'; ?>