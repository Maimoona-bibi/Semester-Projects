<?php
// event-details.php
include('db.php');
include('header.php');

// Check karna ke URL mein ID aayi hai ya nahi
if(isset($_GET['id']))
{
    $event_id = mysqli_real_escape_string($conn, $_GET['id']);

    // Database se us specific ID ka data mangwana
    $query = "SELECT * FROM events WHERE id='$event_id' LIMIT 1";
    $query_run = mysqli_query($conn, $query);

    if(mysqli_num_rows($query_run) > 0)
    {
        $event = mysqli_fetch_assoc($query_run);
        $formatted_date = date('F d, Y', strtotime($event['event_date']));
    }
    else
    {
        echo "<h3 style='text-align:center; margin-top:50px;'>Event Not Found!</h3>";
        include('footer.php');
        exit(0);
    }
}
else
{
    echo "<h3 style='text-align:center; margin-top:50px;'>No Event ID Given!</h3>";
    include('footer.php');
    exit(0);
}
?>

<!-- Event Details Design -->
<section class="section" style="padding: 60px 20px; background: #f9f9f9; min-height: 80vh;">
    <div style="max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.1);">
        
        <!-- Back Button -->
        <a href="index.php" style="text-decoration: none; color: #555; font-weight: bold; margin-bottom: 20px; display: inline-block;">
            &larr; Back to Home
        </a>

        <!-- Event Date Badge -->
        <div style="margin-top: 10px;">
            <span style="background: #e8f5e9; color: #168a53; padding: 8px 15px; border-radius: 20px; font-weight: bold;">
                <?= $formatted_date; ?>
            </span>
        </div>

        <!-- Event Title -->
        <h1 style="color: #333; margin-top: 20px; font-size: 2.5rem;"><?= $event['title']; ?></h1>

        <!-- Venue -->
        <p style="font-size: 1.1rem; color: #555; margin-top: 10px;">
            <strong><i class="fas fa-map-marker-alt"></i> Venue:</strong> <?= $event['venue']; ?>
        </p>

        <!-- IMAGE DISPLAY LOGIC ADDED HERE -->
        <?php if(!empty($event['event_image'])): ?>
            <div style="margin-top: 30px; border-radius: 10px; overflow: hidden; box-shadow: 0 4px 10px rgba(0,0,0,0.1);">
                <!-- Image ka path 'uploads/' folder se match hona chahiye -->
                <img src="uploads/<?= $event['event_image']; ?>" 
                     alt="Event Image" 
                     style="width: 100%; height: auto; display: block;">
            </div>
        <?php endif; ?>
        
        <hr style="border: 1px solid #eee; margin: 25px 0;">

        <!-- Event Full Description -->
        <div style="line-height: 1.8; color: #444; font-size: 1.1rem;">
            <h3>Event Details</h3>
            <p>
                <?= nl2br($event['description']); ?> 
            </p>
        </div>

    </div>
</section>

<?php include('footer.php'); ?>