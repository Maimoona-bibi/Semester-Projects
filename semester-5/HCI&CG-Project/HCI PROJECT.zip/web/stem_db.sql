-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 26, 2025 at 11:52 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stem_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `cabinet_roles`
--

CREATE TABLE `cabinet_roles` (
  `id` int(11) NOT NULL,
  `role_name` varchar(100) NOT NULL,
  `min_semester` int(11) NOT NULL,
  `max_semester` int(11) NOT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cabinet_roles`
--

INSERT INTO `cabinet_roles` (`id`, `role_name`, `min_semester`, `max_semester`, `description`) VALUES
(1, 'President', 6, 8, 'Leads the society and oversees all operations. (Eligibility: 6th–8th semester)'),
(2, 'Vice President', 5, 8, 'Assists the President and manages internal teams. (Eligibility: 5th–8th semester)'),
(3, 'General Secretary', 4, 8, 'Responsible for documentation, records, and communication. (Eligibility: 4th semester & above)'),
(4, 'Treasurer', 4, 8, 'Manages society finances and budgeting. (Eligibility: 4th semester & above)');

-- --------------------------------------------------------

--
-- Table structure for table `chapters`
--

CREATE TABLE `chapters` (
  `id` int(11) NOT NULL,
  `chapter_name` varchar(100) NOT NULL,
  `head_name` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `chapters`
--

INSERT INTO `chapters` (`id`, `chapter_name`, `head_name`, `description`, `created_at`) VALUES
(1, 'enterpreneurship', 'moona', 'kuch bhi dal do', '2025-11-19 09:28:59'),
(2, 'web engineering', 'Ma\'am Quratulain ', 'bdpoebfndfdgurfdo', '2025-11-20 07:10:57');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `event_date` date NOT NULL,
  `venue` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `title`, `event_date`, `venue`, `description`, `created_at`) VALUES
(1, 'stem dinner', '2025-11-12', 'auditorium', 'kuch bhi', '2025-11-19 09:04:02'),
(2, 'seminaar', '2025-04-11', 'auditorium', 'khana kha lo', '2025-11-20 07:08:30');

-- --------------------------------------------------------

--
-- Table structure for table `gallery_images`
--

CREATE TABLE `gallery_images` (
  `id` int(11) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `caption` varchar(100) DEFAULT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gallery_images`
--

INSERT INTO `gallery_images` (`id`, `image_path`, `caption`, `uploaded_at`) VALUES
(2, '1763720703_WhatsApp Image 2025-11-21 at 3.23.43 PM (2).jpeg', '', '2025-11-21 10:25:03'),
(3, '1763720756_WhatsApp Image 2025-11-21 at 3.23.43 PM.jpeg', '', '2025-11-21 10:25:56'),
(4, '1763720764_WhatsApp Image 2025-11-21 at 3.23.44 PM (1).jpeg', '', '2025-11-21 10:26:04');

-- --------------------------------------------------------

--
-- Table structure for table `nominations`
--

CREATE TABLE `nominations` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `role_name` varchar(100) NOT NULL,
  `manifesto` text NOT NULL,
  `nomination_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('pending','approved','rejected','withdrawn') DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `nominations`
--

INSERT INTO `nominations` (`id`, `user_id`, `role_id`, `role_name`, `manifesto`, `nomination_date`, `status`) VALUES
(1, 6, 2, 'Vice President', 'Our goal is to build a better, fair, and peaceful country for everyone. We believe that every citizen should have equal chances to grow, learn, and succeed. Our first priority is to improve education so that every child can study in a good school and learn modern skills. We want students to have access to technology, creative learning, and safe classrooms.\r\n\r\nHealth is also very important for us. We want to make hospitals better, medicines affordable, and doctors easily available for all people. No one should suffer because they cannot pay for treatment.\r\n\r\nTo reduce unemployment, we will create new job opportunities by supporting small businesses, encouraging new industries, and promoting digital skills. We aim to control rising prices so that daily life becomes easier for families. We will also work to make transportation, electricity, and clean water more reliable.\r\n\r\nOur vision is to build a fair justice system where laws apply equally to every person. We want to ensure safety in every city and village by strengthening community policing and promoting peace.\r\n\r\nWe believe in unity, honesty, and responsibility. Together, we can build a strong, successful, and hopeful future for our nation.', '2025-11-20 07:44:11', 'approved'),
(2, 6, 3, 'General Secretary', 'Our goal is to build a better, fair, and peaceful country for everyone. We believe that every citizen should have equal chances to grow, learn, and succeed. Our first priority is to improve education so that every child can study in a good school and learn modern skills. We want students to have access to technology, creative learning, and safe classrooms.\r\n\r\nHealth is also very important for us. We want to make hospitals better, medicines affordable, and doctors easily available for all people. No one should suffer because they cannot pay for treatment.\r\n\r\nTo reduce unemployment, we will create new job opportunities by supporting small businesses, encouraging new industries, and promoting digital skills. We aim to control rising prices so that daily life becomes easier for families. We will also work to make transportation, electricity, and clean water more reliable.\r\n\r\nOur vision is to build a fair justice system where laws apply equally to every person. We want to ensure safety in every city and village by strengthening community policing and promoting peace.\r\n\r\nWe believe in unity, honesty, and responsibility. Together, we can build a strong, successful, and hopeful future for our nation.', '2025-11-20 07:45:59', 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `department` varchar(50) NOT NULL,
  `stem_id` varchar(20) DEFAULT NULL,
  `role` varchar(20) DEFAULT 'student',
  `chapter_id` int(11) DEFAULT NULL,
  `semester` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullname`, `full_name`, `email`, `password`, `department`, `stem_id`, `role`, `chapter_id`, `semester`, `created_at`) VALUES
(2, '', 'Admin', 'admin@fjwu.edu.pk', '$2y$10$9Ja8VF2sXjoDzkwfhV7woeyMvURDsDQCHcuxvuuPfrCp6qd1YC5xq', 'Other', 'STEM-25-2771', 'admin', NULL, 1, '2025-11-19 08:46:30'),
(6, 'Maimoona Bibi', '', 'kanwalpervaiz080@gmail.com', 'kanwal', '', '2023-bcs-055', 'student', 1, 5, '2025-11-19 11:07:24'),
(7, 'amina jabeen', '', 'amina@srms.com', 'amina', '', '123- cs-11', 'student', 1, 3, '2025-11-20 06:47:06'),
(8, 'fatima', '', 'fatima@gmail.com', 'fatima', '', '2025-eng-12', 'student', 1, 6, '2025-11-20 06:56:45'),
(9, 'Ritj Fatima', '', 'ritaj@gmail.com', 'ritaj', '', 'STEM-25-6331', 'student', 2, 6, '2025-11-21 10:41:36');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cabinet_roles`
--
ALTER TABLE `cabinet_roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `role_name` (`role_name`);

--
-- Indexes for table `chapters`
--
ALTER TABLE `chapters`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `chapter_name` (`chapter_name`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery_images`
--
ALTER TABLE `gallery_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nominations`
--
ALTER TABLE `nominations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_nomination` (`user_id`,`role_id`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `stem_id` (`stem_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cabinet_roles`
--
ALTER TABLE `cabinet_roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `chapters`
--
ALTER TABLE `chapters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `gallery_images`
--
ALTER TABLE `gallery_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `nominations`
--
ALTER TABLE `nominations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `nominations`
--
ALTER TABLE `nominations`
  ADD CONSTRAINT `nominations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `nominations_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `cabinet_roles` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
